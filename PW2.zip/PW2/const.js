const nome = "Joao & Carlos"
console.log(nome)

