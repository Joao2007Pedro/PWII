export default function celsius(celsius){
    return (celsius * 9/5) + 32;
}